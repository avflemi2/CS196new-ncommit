HelloWorld-AE is an Eclipse project that should help to get you started. It has been written based on the 2.1u1 SDK.

HelloShader is an Eclipse project that shows how to use custom shaders with OpenGL ES 2.0. It has been written based on the 2.3.3 SDK.