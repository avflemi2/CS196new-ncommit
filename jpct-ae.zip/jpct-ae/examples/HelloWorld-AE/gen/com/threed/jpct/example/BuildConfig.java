/** Automatically generated file. DO NOT MODIFY */
package com.threed.jpct.example;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}